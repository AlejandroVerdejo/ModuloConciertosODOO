from datetime import datetime
from odoo import models, fields, api, exceptions

# Modelo Concierto
class conciertos_concierto(models.Model):
    _name = "conciertos.concierto"
    _description = "Concierto"
    
    name = fields.Char(string="Nombre",required=True,help="Introduce el nombre del concierto")
    grupo = fields.Many2one("conciertos.grupo",string="Grupo",required=True,ondelete="cascade")
    canciones = fields.Many2many("conciertos.cancion",string="Canciones",domain="[('grupo', '=', grupo)]", attrs={'readonly': [('grupo', '=', False)]},required=True)
    fecha = fields.Date(string="Fecha del concierto",required=True)
    entradas = fields.Integer(string="Entradas")
    precio = fields.Float(string="Precio")

    # @api.onchange('grupo')
    # def _onchange_grupo_set_canciones(self):
    #     if self.grupo:
    #         domain = [('grupo', '=', self.grupo.id)]
    #         return {'domain': {'canciones': domain}}
    #     else:
    #         domain = [('grupo', '=', 0)]
    #         return {'domain': {'canciones': []}}

    @api.constrains('name')
    def _check_name_long(self):
        for r in self:
            if len(r.name) < 10:
                raise exceptions.ValidationError("El nombre de la categoria debe tener al menos 10 caracteres")   

    @api.constrains('fecha')
    def check_duplicate_date(self):
        for record in self:
            if self.search_count([('fecha', '=', record.fecha)]) > 1:
                raise exceptions.ValidationError("Ya existe un concierto para esa fecha.")

    def enviarCorreoGrupo(self):
        self.grupo.enviarCorreo()

# Modelo Grupo
class conciertos_grupo(models.Model):
    _name = "conciertos.grupo"
    _description = "Grupo"

    imagen = fields.Binary(string="Imagen")
    name = fields.Char(string="Nombre",required=True)
    email = fields.Char(string="Correo electronico")
    miembros = fields.Many2many("conciertos.miembro",string="Miembros",ondelete="cascade",required=True)
    miembros_detalles = fields.Html(compute='_compute_miembros_detalles')
    canciones = fields.One2many('conciertos.cancion', 'grupo', string="Canciones")
    canciones_detalles = fields.Html(string="Canciones",compute='_compute_canciones_detalles')

    _sql_constraints = [
        ('name_grupo_unique',
         'UNIQUE(name)',
         "Ya existe un grupo con ese nombre"),
    ]

    @api.constrains('miembros')
    def check_duplicate_miembro(self):
        for record in self:
            for miembro in record.miembros:
                if self.search_count([('miembros', 'in', miembro.ids)]) > 1:
                    raise exceptions.ValidationError("Uno de los miembros ya es parte de otro grupo.")

    def enviarCorreo(self):
        if self.email:
            raise exceptions.ValidationError("Se ha enviado el correo a " + self.email)
        else:
            raise exceptions.ValidationError("El grupo no tiene un correo asignado")

    @api.depends('miembros')
    def _compute_miembros_detalles(self):
        for grupo in self:
            miembros_detalles = "<ul style='list-style-type:none;'>"
            for miembro in grupo.miembros:
                miembros_detalles += f"<li><a href='/web#id={miembro.id}&model=conciertos.miembro' style='text-decoration: none;'><img src='/web/image/conciertos.miembro/{miembro.id}/imagen/' style='width: 50px; height: 50px;'/><span style='color: black; font-weight: semibold; font-size: 15px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{miembro.name}</span></a></li></br>"
            miembros_detalles += "</ul>"
            grupo.miembros_detalles = miembros_detalles  

    @api.depends('canciones')
    def _compute_canciones_detalles(self):
        for grupo in self:
            canciones_detalles = "<ul style='list-style-type:none;'>"
            for cancion in grupo.canciones:
                canciones_detalles += f"<li><a href='/web#id={cancion.id}&model=conciertos.cancion' style='text-decoration: none;'><img src='/web/image/conciertos.cancion/{cancion.id}/imagen/' style='width: 50px; height: 50px;'/><span style='color: black; font-weight: semibold; font-size: 15px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{cancion.name}</span></a></li></br>"
            canciones_detalles += "</ul>"
            grupo.canciones_detalles = canciones_detalles   

# Modelo Miembro
class conciertos_miembro(models.Model):
    _name = "conciertos.miembro"
    _description = "Miembro"
    
    imagen = fields.Binary(string="Imagen")
    name = fields.Char(string="Nombre",required=True)
    fecha_nacimiento = fields.Date(string="Fecha de nacimiento")
    edad = fields.Integer(string="Edad",compute="_edad",store=True)

    _sql_constraints = [
        ('name_miembro_unique',
         'UNIQUE(name)',
         "Ya existe un miembro con ese nombre"),
    ]    

    @api.depends('fecha_nacimiento')
    def _edad(self):
        fecha_actual = datetime.today().date()
        for r in self:
            if r.fecha_nacimiento:
                fecha_nacimiento = r.fecha_nacimiento
                r.edad = fecha_actual.year - fecha_nacimiento.year - ((fecha_actual.month, fecha_actual.day) < (fecha_nacimiento.month, fecha_nacimiento.day))    

    def action_view_miembro(self):
        action = self.env.ref('conciertos.conciertos_miembro_action')
        result = action.read()[0]
        result['views'] = [(False, 'form')]
        result['res_id'] = self.id
        return result

# Modelo Cancion
class conciertos_cancion(models.Model):
    _name = "conciertos.cancion"
    _description = "Cancion"

    imagen = fields.Binary(string="Imagen")
    name = fields.Char(string="Nombre",required=True)
    grupo = fields.Many2one("conciertos.grupo",string="Grupo",required=True,ondelete="cascade")
    duracion = fields.Float(string="Duracion")
    genero = fields.Many2many("conciertos.genero",string="Generos",ondelete="cascade")

    def action_view_cancion(self):
        action = self.env.ref('conciertos.conciertos_cancion_action')
        result = action.read()[0]
        result['views'] = [(False, 'form')]
        result['res_id'] = self.id
        return result    

# Modelo Genero
class conciertos_genero(models.Model):
    _name = "conciertos.genero"
    _description = "Genero"

    name = fields.Char(string="Nombre",required=True)

    _sql_constraints = [
        ('name_genero_unique',
         'UNIQUE(name)',
         "Ya existe un genero con ese nombre"),
    ]    
